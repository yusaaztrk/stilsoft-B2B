import React from 'react';
import { DefaultProps, MantineNumberSize, MantineColor, Selectors } from '@mantine/styles';
import { MarksStylesNames } from '../Marks/Marks';
import useStyles from './Track.styles';
export type TrackStylesNames = Selectors<typeof useStyles> | MarksStylesNames;
export interface TrackProps extends DefaultProps<TrackStylesNames> {
    filled: number;
    offset?: number;
    marksOffset?: number;
    marks: {
        value: number;
        label?: React.ReactNode;
    }[];
    size: MantineNumberSize;
    thumbSize?: number;
    radius: MantineNumberSize;
    color: MantineColor;
    min: number;
    max: number;
    value: number;
    children: React.ReactNode;
    onChange(value: number): void;
    disabled: boolean;
    inverted?: boolean;
    variant: string;
    containerProps?: React.PropsWithRef<React.ComponentProps<'div'>>;
}
export declare function Track({ filled, size, thumbSize, color, classNames, styles, radius, children, offset, disabled, marksOffset, unstyled, inverted, variant, containerProps, ...others }: TrackProps): JSX.Element;
export declare namespace Track {
    var displayName: string;
}
//# sourceMappingURL=Track.d.ts.map