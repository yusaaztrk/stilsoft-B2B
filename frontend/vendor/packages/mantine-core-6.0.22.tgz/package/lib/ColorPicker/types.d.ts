export type ColorFormat = 'hex' | 'hexa' | 'rgba' | 'rgb' | 'hsl' | 'hsla';
export interface HsvaColor {
    h: number;
    s: number;
    v: number;
    a: number;
}
export interface RgbaColor {
    r: number;
    g: number;
    b: number;
    a: number;
}
//# sourceMappingURL=types.d.ts.map